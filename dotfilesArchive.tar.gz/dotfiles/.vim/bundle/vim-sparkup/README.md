Sparkup for Vim
==============
Just the vim version of [Sparkup](https://github.com/rstacruz/sparkup) tailored for easy installation with pathogen.

Installation
------------
Like [@tpope](http://github.com/tpope) says:

If you don't have a preferred installation method, I recommend
installing [pathogen.vim](https://github.com/tpope/vim-pathogen), and
then simply copy and paste:

    cd ~/.vim/bundle
    git clone git://github.com/tristen/vim-sparkup.git

Once help tags have been generated, you can view the manual with
`:help sparkup`.

Credit
------------
[http://github.com/rstacruz/sparkup](http://github.com/rstacruz/sparkup)
