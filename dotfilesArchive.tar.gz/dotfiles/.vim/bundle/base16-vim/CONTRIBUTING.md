# Contributing
These files are automtically built with [Base16 Builder](https://github.com/chriskempson/base16-builder), no pull requests will be accepted to this repository. However, please feel free to submit issues to this repository.
